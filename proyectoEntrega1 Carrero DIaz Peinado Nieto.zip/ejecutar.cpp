#include "Comandos.h"

int main() {
    Comandos comandos;
    comandos.run();
    return 0;
}

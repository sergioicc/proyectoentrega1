#include "Comandos.h"
#include <iostream>
#include <string>
#include <fstream>
#include "Objeto3D.h"
#include <algorithm>  // para std::min_element y std::max_element
using namespace std;

void Comandos::run() {
    string comando;

    while (true) {
        cout << "$ ";
        getline(cin, comando);

        if (comando.find("ayuda") == 0) {
            if (comando.length() > 6) {
                string param = comando.substr(6);
                mostrarAyudaComando(param);
            } else {
                mostrarAyuda();
            }
        } else if (comando.find("cargar") == 0) {
            if (comando.length() > 7) {
                string param = comando.substr(7);
                ejecutarCargar(param);
            } else {
                cout << "Uso: cargar <nombre_archivo>\n";
            }
        } else if (comando == "listado") {
            ejecutarListado();
        } else if (comando.find("envolvente") == 0) {
            if (comando.length() > 11) {
                string param = comando.substr(11);
                ejecutarEnvolventeObjeto(param);
            } else {
                cout << "Envolvente de un objeto en memoria.\n";
            }
        } else if (comando.find("Tenvolvente") == 0) {
            if (cantObjetos == 0){
                cout<<"Envolvente de todos los objetos en memoria(aun no se ha guardado ningun objeto).\n";
            }else {
                ejecutarEnvolvente();
            }
        } else if (comando.find("descargar") == 0) {
            if (comando.length() > 10) {
                string param = comando.substr(10);
                ejecutarDescargar(param);
            } else {
                cout << "Uso: descargar <nombre_objeto>\n";
            }
        } else if (comando.find("guardar") == 0) {
            // Encuentra el primer espacio después de "guardar"
            size_t pos1 = comando.find(' ', 7);

            if (pos1 != string::npos && pos1 + 1 < comando.length()) {
                // Encuentra el siguiente espacio después del nombre del objeto
                size_t pos2 = comando.find(' ', pos1 + 1);

                // Si se encuentra otro espacio, separamos nombre del objeto y archivo
                if (pos2 != string::npos) {
                    string param1 = comando.substr(8, pos2 - 8); // Nombre del objeto
                    string param2 = comando.substr(pos2 + 1);     // Nombre del archivo

                    if (!param1.empty() && !param2.empty()) {
                        ejecutarGuardar(param1, param2);
                    } else {
                        cout << "Uso: guardar <nombre_objeto> <nombre_archivo>\n";
                    }
                } else {

                    string param1 = comando.substr(8, pos1 - 8);  // Nombre del objeto
                    string param2 = comando.substr(pos1 + 1);     // Nombre del archivo

                    if (!param1.empty() && !param2.empty()) {
                        ejecutarGuardar(param1, param2);
                    } else {
                        cout << "Uso: guardar <nombre_objeto> <nombre_archivo>\n";
                    }
                }
            } else {
                cout << "Uso: guardar <nombre_objeto> <nombre_archivo>\n";
            }
        } else if (comando == "clear") {
            ejecutarClear();
        } else if (comando == "salir") {
            break;
        } else {
            cout << "Comando no reconocido o parametros incorrectos.\n";
        }
    }
}

void Comandos::mostrarAyuda() {
    cout << "Comandos disponibles:\n";
    cout << "  ayuda [comando] - Muestra esta ayuda o la ayuda de un comando especifico\n";
    cout << "  cargar <nombre_archivo> - Carga un objeto 3D desde un archivo\n";
    cout << "  listado - Lista los objetos cargados en memoria\n";
    cout << "  envolvente [nombre_objeto] - Calcula la caja envolvente de un objeto o de todos los objetos\n";
    cout <<   "Tenvolvente - calcula la caja envolvente de todos los objetos en el sistema\n";
    cout << "  descargar <nombre_objeto> - Descarga un objeto de la memoria\n";
    cout << "  guardar <nombre_objeto> <nombre_archivo> - Guarda un objeto en un archivo\n";
    cout << "  clear - Limpia la consola\n";
    cout << "  salir - Termina la ejecucion de la aplicacion\n";
}

void Comandos::mostrarAyudaComando(const string& comando) {
     if (comando == "cargar") {
        cout << "Uso: cargar <nombre_archivo>\n";
        cout << "Descripcion: Carga un objeto 3D desde un archivo.\n";
    } else if (comando == "listado") {
        cout << "Uso: listado\n";
        cout << "Descripcion: Lista los objetos cargados en memoria.\n";
    } else if (comando == "envolvente objeto") {
        cout << "Uso: envolvente [nombre_objeto]\n";
        cout << "Descripcion: Calcula la caja envolvente de un objeto.\n";
    }else if(comando == "tenvolvente"){
        cout<< "Uso: envolvente \n";
        cout<< "Descripcion: Calcula la caja envolvente de todos los objetos.";
    }
     else if (comando == "descargar") {
        cout << "Uso: descargar <nombre_objeto>\n";
        cout << "Descripcion: Descarga un objeto de la memoria.\n";
    } else if (comando == "guardar") {
        cout << "Uso: guardar <nombre_objeto> <nombre_archivo>\n";
        cout << "Descripcion: Guarda un objeto en un archivo.\n";
    } else if (comando == "clear") {
        cout << "Uso: clear\n";
        cout << "Descripcion: Limpia la consola.\n";
    } else if (comando == "salir") {
        cout << "Uso: salir\n";
        cout << "Descripcion: Termina la ejecucion de la aplicacion.\n";
    } else {
        cout << "Comando no reconocido.\n";
    }
}

bool Comandos::archivoExiste(const string& nombreArchivo) {
    ifstream archivo(nombreArchivo); // Usa el nombre del archivo proporcionado
    return archivo.good(); // Verifica si el archivo está abierto correctamente
}

bool Comandos::objetoExiste(const string& nombreObjeto) {
    for (const auto& obj : objetosCargados) {
        if (obj.nombre == nombreObjeto) {
            return true;
        }
    }
    return false;

}

void Comandos::ejecutarCargar(const string& nombreArchivo) {
    if (archivoExiste(nombreArchivo)) {
        ifstream file(nombreArchivo);

        if (!file.is_open()) {
            cerr << "No se pudo abrir el archivo: " << nombreArchivo << endl;
            return;
        }

        Object3D objeto;
        string line;
        int nPuntos=0;

        getline(file, line);
        objeto.nombre = line;
        cout<<line<<endl;

        getline(file, line);
        cout<<line<<endl;
        try {
            nPuntos = stoi(line);
            objeto.cantPuntos=nPuntos;
        } catch (const invalid_argument& e) {
            cerr << "Error: La linea no es un numero valido: " << line << endl;
            return;
        }
        for (int n = 0; n < nPuntos; n++) {
            float x=0, y=0, z=0;
            file >> x >> y >> z;

            Punto punto(x, y, z);
            objeto.puntos.push_back(punto);
        }
        int nPuntosxCara,caras=0;
        file >> nPuntosxCara;


        while (nPuntosxCara != -1) {
            objeto.cantAristas=objeto.cantAristas+nPuntosxCara;
            Cara cara;
            caras++;
            objeto.cantCaras=caras;
            cara.vertices.clear(); // Asegurarse de limpiar la lista de vértices antes de llenar la nueva cara

            for (int i = 0; i < nPuntosxCara; i++) {
                int a;
                file >> a;
                cara.vertices.push_back(objeto.puntos[a]);

            }
            objeto.caras.push_back(cara);
            file >> nPuntosxCara;
        }
        objetosCargados.push_back(objeto);
        file.close();
        cantObjetos++;
    } else {
        return;
    }
}

void Comandos::ejecutarListado() {
    cout << "Listado de objetos en memoria:\n";
    for (const auto& objeto : objetosCargados) {
        cout <<"    "<<objeto.nombre<<" contiene "<<objeto.cantPuntos<<" vertices, " <<objeto.cantAristas <<" aristas y "<<objeto.cantCaras<<" caras."<<endl;

    }
}

void Comandos::ejecutarEnvolventeObjeto(const string& nombreObjeto) {
    cout << "Envolvente del objeto: " << nombreObjeto << "\n";

    for(int b=0; b<cantObjetos; b++){
        objetoActual=objetosCargados[b];
        if(nombreObjeto==objetoActual.nombre)
            break;
    }
    int xMax=-9000, yMax=-9000, zMax=-9000, xMin=70000, yMin=70000, zMin=90000;

    for(const auto& punto : objetoActual.puntos) {
        if(punto.x > xMax) xMax = punto.x;
        if(punto.x < xMin) xMin = punto.x;
        if(punto.y > yMax) yMax = punto.y;
        if(punto.y < yMin) yMin = punto.y;
        if(punto.z > zMax) zMax = punto.z;
        if(punto.z < zMin) zMin = punto.z;
    }

    Object3D envolvente;

    envolvente.nombre="env_"+objetoActual.nombre;
    Punto punto1(xMax,yMax,zMax);
    Punto punto2(xMax,yMax,zMin);
    Punto punto3(xMax,yMin,zMax);
    Punto punto4(xMax,yMin,zMin);
    Punto punto5(xMin,yMax,zMax);
    Punto punto6(xMin,yMax,zMin);
    Punto punto7(xMin,yMin,zMax);
    Punto punto8(xMin,yMin,zMin);
    envolvente.puntos.push_back(punto1);
    envolvente.puntos.push_back(punto2);
    envolvente.puntos.push_back(punto3);
    envolvente.puntos.push_back(punto4);
    envolvente.puntos.push_back(punto5);
    envolvente.puntos.push_back(punto6);
    envolvente.puntos.push_back(punto7);
    envolvente.puntos.push_back(punto8);

    Cara cara1 = {envolvente.puntos[0], envolvente.puntos[2], envolvente.puntos[6], envolvente.puntos[4]};
    envolvente.caras.push_back(cara1);
    envolvente.cantCaras++;

    Cara cara2 = {envolvente.puntos[1], envolvente.puntos[3], envolvente.puntos[7], envolvente.puntos[5]};
    envolvente.caras.push_back(cara2);
    envolvente.cantCaras++;

    Cara cara3 = {envolvente.puntos[4], envolvente.puntos[6], envolvente.puntos[7], envolvente.puntos[5]};
    envolvente.caras.push_back(cara3);
    envolvente.cantCaras++;

    Cara cara4 = {envolvente.puntos[0], envolvente.puntos[2], envolvente.puntos[3], envolvente.puntos[1]};
    envolvente.caras.push_back(cara4);
    envolvente.cantCaras++;

    Cara cara5 = {envolvente.puntos[0], envolvente.puntos[1], envolvente.puntos[5], envolvente.puntos[4]};
    envolvente.caras.push_back(cara5);
    envolvente.cantCaras++;

    Cara cara6 = {envolvente.puntos[2], envolvente.puntos[3], envolvente.puntos[7], envolvente.puntos[6]};
    envolvente.caras.push_back(cara6);
    envolvente.cantCaras++;
    envolvente.cantAristas=12;
    envolvente.cantPuntos=8;
    objetosCargados.push_back(envolvente);
}

void Comandos::ejecutarEnvolvente() {
    int xMax=-9000, yMax=-9000, zMax=-9000, xMin=70000, yMin=70000, zMin=90000;

    for (int b = 0; b < cantObjetos; b++) {
        objetoActual = objetosCargados[b];
        for (const auto& punto : objetoActual.puntos) {
            if (punto.x > xMax) xMax = punto.x;
            if (punto.x < xMin) xMin = punto.x;
            if (punto.y > yMax) yMax = punto.y;
            if (punto.y < yMin) yMin = punto.y;
            if (punto.z > zMax) zMax = punto.z;
            if (punto.z < zMin) zMin = punto.z;
        }
    }

    Object3D envolvente;
    envolvente.nombre = "env_global";
   // envolvente.puntos.resize(8);
    Punto punto1(xMax,yMax,zMax);
    Punto punto2(xMax,yMax,zMin);
    Punto punto3(xMax,yMin,zMax);
    Punto punto4(xMax,yMin,zMin);
    Punto punto5(xMin,yMax,zMax);
    Punto punto6(xMin,yMax,zMin);
    Punto punto7(xMin,yMin,zMax);
    Punto punto8(xMin,yMin,zMin);
    envolvente.puntos.push_back(punto1);
    envolvente.puntos.push_back(punto2);
    envolvente.puntos.push_back(punto3);
    envolvente.puntos.push_back(punto4);
    envolvente.puntos.push_back(punto5);
    envolvente.puntos.push_back(punto6);
    envolvente.puntos.push_back(punto7);
    envolvente.puntos.push_back(punto8);

    Cara cara1 = {envolvente.puntos[0], envolvente.puntos[2], envolvente.puntos[6], envolvente.puntos[4]};
    envolvente.caras.push_back(cara1);
    envolvente.cantCaras++;

    Cara cara2 = {envolvente.puntos[1], envolvente.puntos[3], envolvente.puntos[7], envolvente.puntos[5]};
    envolvente.caras.push_back(cara2);
    envolvente.cantCaras++;

    Cara cara3 = {envolvente.puntos[4], envolvente.puntos[6], envolvente.puntos[7], envolvente.puntos[5]};
    envolvente.caras.push_back(cara3);
    envolvente.cantCaras++;

    Cara cara4 = {envolvente.puntos[0], envolvente.puntos[2], envolvente.puntos[3], envolvente.puntos[1]};
    envolvente.caras.push_back(cara4);
    envolvente.cantCaras++;

    Cara cara5 = {envolvente.puntos[0], envolvente.puntos[1], envolvente.puntos[5], envolvente.puntos[4]};
    envolvente.caras.push_back(cara5);
    envolvente.cantCaras++;

    Cara cara6 = {envolvente.puntos[2], envolvente.puntos[3], envolvente.puntos[7], envolvente.puntos[6]};
    envolvente.caras.push_back(cara6);
    envolvente.cantCaras++;

    envolvente.cantAristas=12;
    envolvente.cantPuntos=8;
    envolvente.cantCaras=6;
    objetosCargados.push_back(envolvente);
}

void Comandos::ejecutarDescargar(const string& nombreObjeto) {

    if (objetoExiste(nombreObjeto)) {
        for(int b=0; b<cantObjetos; b++){
            if(nombreObjeto==objetosCargados[b].nombre)
                if (0 <= b && b < objetosCargados.size()) {
                    objetosCargados.erase(objetosCargados.begin() + b);
                }
        }

        cout << "El objeto " << nombreObjeto << "ha sido eliminado de la memoria de trabajo."<<endl;
    } else {
        cout << "Error: El objeto " << nombreObjeto << " no existe.\n";
    }
}
void Comandos::ejecutarGuardar(const string& nombreObjeto, const string& nombreArchivo) {
    cout<<nombreObjeto<<endl;
    if (!objetoExiste(nombreObjeto)) {
        cout << "Error: el objeto " << nombreObjeto << " no existe.\n";
        return;
    }

    Object3D objetoGuardar;
    for (const auto& obj : objetosCargados) {
        if (obj.nombre == nombreObjeto) {
            objetoGuardar = obj;
            break;
        }
    }
    cout << "Objeto seleccionado tiene " << objetoGuardar.puntos.size() << " puntos y " << objetoGuardar.caras.size() << " caras." << endl;
    ofstream archivo(nombreArchivo+".txt");
    if (!archivo.is_open()) {
        cout << "Error: no se pudo abrir el archivo " << nombreArchivo << " para guardar.\n";
        return;
    }

    archivo << objetoGuardar.nombre << endl;
    archivo << objetoGuardar.cantPuntos << endl;

    // Escribir cada vértice
    for (const auto& punto : objetoGuardar.puntos) {
        archivo << punto.x << " " << punto.y << " " << punto.z << endl;
    }

    // Escribir cada cara
    for (const auto& cara : objetoGuardar.caras) {
        archivo << cara.vertices.size();
        for (const auto& vertice : cara.vertices) {
            int indice = -1;
            for (int i = 0; i < objetoGuardar.puntos.size(); i++) {
                if (objetoGuardar.puntos[i].x == vertice.x &&
                    objetoGuardar.puntos[i].y == vertice.y &&
                    objetoGuardar.puntos[i].z == vertice.z) {
                    indice = i;
                    break;
                }
            }
            if (indice != -1) {
                archivo << " " << indice;  // Un solo espacio para separar los índices
            } else {
                cout << "Advertencia: no se encontró un vértice correspondiente.\n";
            }
        }
        archivo << endl;
    }
    cout<<"Archivo creado exitosamente.\n";
}

void Comandos::ejecutarClear() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}